package com.tiendadeportiva.tiendavirtual.role;
//@org.springframework.context.annotation.Role(1)
public enum Role {

    ADMIN, OPERARIO
}
